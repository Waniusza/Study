package com.gut.waniusza.semestr_5.progWspol.colloquium_3_online.result;

/**
 *
 * @author janusz
 */
public class Sum {

    public Sum() {
    }

    
    public double sum = 0;
}
